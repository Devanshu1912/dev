print("chavda riyaz")

# to check the whole string is in lower case or not

str1="chavda riyaz"
print(str1.islower())

str2="CHAVDA riayz"
print(str2.islower())
