#to conver the upper in lower and lower in upper	

str1="Chavda Riayz"
print(str1.swapcase())

str2="last night"
print(str2.swapcase())
