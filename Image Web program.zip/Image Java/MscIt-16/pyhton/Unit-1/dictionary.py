print("chavda riyaz")

pd = {"class": 'Msc It', "Section": 'A', "Roll No": 16}
print(pd)
print(pd["class"])
print(pd["Section"])
print(pd["Roll No"])


