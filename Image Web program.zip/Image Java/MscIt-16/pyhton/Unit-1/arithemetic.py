print("chavda riyaz")

a=10;
b=3;

c=a+b
print("Additon is: ",c)

c=a-b
print("Substraction is: ",c)

c=a*b
print("Multiplication is: ",c)

c=a/b
print("Division is: ",c)

c=a//b
print("Floor Division is: ",c)

c=a%b
print("Modulas Division is: ",c)

c=a**b
print("Dubble Multiplication is: ",c)
