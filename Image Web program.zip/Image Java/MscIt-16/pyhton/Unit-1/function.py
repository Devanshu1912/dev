var1 = "python"
def func1():
    var1 = "php"
    print("In side func1() = ",var1)

def func2():
    print("In side func2() = ",var1)

func1()
func2()
