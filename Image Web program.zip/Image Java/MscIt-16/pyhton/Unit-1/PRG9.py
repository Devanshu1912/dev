print("chavda riyaz")

var = "python"
def func():
    var ="php"
    print("In side func() var= ",var)

def func1():
    print("In side func2 var= ",var)
func()
func2()
