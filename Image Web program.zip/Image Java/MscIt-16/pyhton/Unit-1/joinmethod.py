print("chavda riyaz")

#to join the sequence with string
str1=" "
seq = ("riyaz","chavda")
print(str1.join(seq))
