print("chavda riyaz")

#to get the lenght of string

st="khambhat"
print("length of the string: ",len(st))
