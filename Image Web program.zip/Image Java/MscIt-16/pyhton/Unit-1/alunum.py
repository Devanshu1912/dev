print("chavda riyaz")

#isalnum() method
