tup1 = (1,2,3,45,0)
print(tup1)

tup2 = ("riyaz","romit","devanshu",20)
print(tup2)

tup3 = ("bsc","msc","sahjanand",10)
print(tup3)

#to print given indexed value's first letter
print(tup2[2][0])

#to print 2 or more value at the same time but it works noly in order
print(tup2[0:3])

#to print above value than 3 of tuppel
print(tup2[:3])

#to conacate the tuppel
alltup = tup1+tup2+tup3
print(alltup)

#to repeat the value of tuppel by the * operator
print(tup1*3)
