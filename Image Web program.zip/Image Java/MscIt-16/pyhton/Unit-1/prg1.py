print("Chavda Riayz")
while True:
    num1=int(input("Enter number  1: "))
    num2=int(input("Enter number 2: "))

    op=input("choose Operation: (+,-,*,/):")

    if op == '+' :
        res=num1+num2
        print("Addition is:",res)
    elif op =='-' :
        res=num1-num2
        print("Substraction is:",res)
    elif op =='*' :
        res=num1*num2
        print("Multiplication is:",res)
    elif op =='/' :
        res=num1/num2
        print("Division is:",res)
        if num2 != 0:
            result = num1 / num2
        else:
            result = "Error: Division by zero"
    else:
        result = "Invalid operation"
    again = input("Do you want to perform another calculation? (yes/no): ").lower()
    if again != 'yes':
        print("Thanks for using the calculator. Goodbye!")
      


    
