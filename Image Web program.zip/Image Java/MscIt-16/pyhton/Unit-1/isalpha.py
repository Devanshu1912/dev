print("chavda riyaz")

#to check the string is alphabatic or not

str1="riyaz"#no space or digits in this
print(str1.isalpha())

str2="riyaz121"#with didgits
print(str2.isalpha())
