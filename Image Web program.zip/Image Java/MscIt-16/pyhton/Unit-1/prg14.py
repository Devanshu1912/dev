string = "Chavda Riyaz"

print(string[1])
print(string[11])
print(string[6])
print(string[12])
