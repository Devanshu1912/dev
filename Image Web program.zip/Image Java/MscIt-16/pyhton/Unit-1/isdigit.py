print("chavda riyaz")

# to check string is in digits or not

str1="10101010" #with only digits and no space
print(str1.isdigit())

str2="riyaz123"# with alphanumeric value
print(str2.isdigit())
