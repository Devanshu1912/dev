str1="string"
print(str1)

str2='string2'
print(str2)

str3="string3'
print(str3)

str4="day's"
print(str4)

str5='day"s'
print(str5)
