print("Chavda riyaz")

x= True
type(x)

y= False
type(y)
