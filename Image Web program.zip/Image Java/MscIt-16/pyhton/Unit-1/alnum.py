print("chavda riyaz")

#isalnum() method to check the string is alpha numeric combination is  or not
str1="123434riyaz"
print(str1.isalnum())

str2="you are mf"
print(str2.isalnum())
