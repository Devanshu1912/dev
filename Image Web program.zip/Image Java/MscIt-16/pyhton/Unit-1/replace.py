str1="My name is riyaz!"

print(str1.replace("My","your"))

#to replace some value of string
str2="is is is is is is is"
print(str2.replace("is","was",3))
