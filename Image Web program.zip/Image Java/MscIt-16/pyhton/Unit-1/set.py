print("chavda riyaz")
a = [1,2,3,4,5,0,0,6,7,8]
#to print unique number 
s1 = set(a)

b = [5,5,6,7,8,9,1,1,2]
s2 = set(b)

#to print the number those are not in s2 but in s1
print(s1-s2)

#to print the inter-section
print(s1|s2)

#to print same nuber in both set
print(s1&s2)

#to print numbers in s1 and s2 but not in both
print(s1^s2)
