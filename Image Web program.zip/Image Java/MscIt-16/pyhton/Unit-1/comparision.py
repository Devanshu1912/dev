a = 100
b = 75

#'== dubble equal to 'operator
if(a==b):
    print(a,"is equal to",b)
else:
    print(a,"is not equal to",b)
    
#'!= not equal to' operator
if(a!=b):
    print(a,"is not equal to",b)
else:
    print(a,"is equal to",b)
    
#'> greater than' operator
if(a>b):
    print(a,"is greater than",b)
else:
    print(b,"greater than",a)
    
#'< less than' operator
if(a<b):
    print(a,"is less than",b)
else:
    print(b,"is less than",a)

#'>= greater than equal to' oerator
if(a>=b):
    print(a,"is either greater than or equal to",b)
else:
    print(a,"is neither greater than nor equal to",b)

#'<= less than equal to' oerator
if(a>=b):
    print(a,"is either less than or equal to",b)
else:
    print(a,"is neither less than nor equal to",b)
    
