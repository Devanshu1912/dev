print("chavda riyaz")

#to check whole string is in upper case or not

str1="CHAVDA RIYAZ"
print(str1.isupper())

str2="CHAVDA riyaz"
print(str2.isupper())
