# to remove the *

str1="***My name is Riyaz****"
print(str1.strip('*'))
