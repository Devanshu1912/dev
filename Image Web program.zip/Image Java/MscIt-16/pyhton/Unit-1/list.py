print("chavda riyaz")

list1 = [1,2,3,4,5,6,7,8,9]
print(list1)

list2 = ["riyaz","romit","harshil"]
print(list2)

list3 = ["old","magic","monk","moment",22,23]
print(list3)

list4 = []
print(list4)

#to print 2 or more list's values at the same time
print(list2[2],list3[3])

#to print given indexed value's any element
print(list3[1][4])

#to print the all value to index 4
print(list3[:4])

#to concate all given list
al_list = list1+list2+list3+list4
print(al_list)

#to repeat the list
print(list2*2)

#to copy the orignal list
print(list1[:])

#to change the value of list at any index
list2[2]="ayush"
print(list2)

#to add value at th e end of the list
list4.append(1)
print(list4)

#to add value at the any index of the lsit
list4.insert(1, 10)
print(list4)

#to add multipel value at the end in the list
list4.extend([4, 5])
print(list4)

