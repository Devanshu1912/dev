#to convert the string in upper case

str1="riyaz lala"
print(str1.upper())
