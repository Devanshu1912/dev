<html>
    <head>
        <title>program-27</title>   
        <script>
            function change() 
            {
                document.getElementById("demo").innerHTML = "Computer science department";
            }
        </script>
    </head>
    <body>
        <p id="demo">ISTAR</p>
        <button onclick="change()">Click to change content</button>
    </body>
</html>
