num = int(input("Enter Number"))

