x=int(input("enter number 1:"))
if x%2==0:
    print(x, "is even number")
else:
    print(x, "is odd number")
