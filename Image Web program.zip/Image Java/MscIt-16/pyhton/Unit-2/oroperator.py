a="riyaz"
m=['romit','harshil','dev']

if a in m:
    print(a+'name')
if a=='manav' or a=='devanshu' or a=='darshil':
    print(a+"name")
