import tkinter as tk

def greet():
    name = entry.get()
    age = entry.get()
    label_result.config(text=f"Hiii,{name} age is,{age}")
window = tk.Tk()
window.title("Greeting App")
window.geometry("500x500")


label1 = tk.Label(window, text="Enter your name:")
label1.pack(pady=5)

entry = tk.Entry(window)
entry.pack(pady=5)

label2 = tk.Label(window, text="Enter your Age:")
label2.pack(pady=10)

entry = tk.Entry(window)
entry.pack(pady=10)

button = tk.Button(window, text="Greet Me", command=greet)
button.pack(pady=5)

label_result = tk.Label(window, text="")
label_result.pack(pady=10)


window.mainloop()
