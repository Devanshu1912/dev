num1=int(input("Enter a number:"))
if num1>=0:
    print("Positive number")
else:
    print("Negative number")
