name=input("What is your name? : ")
num=int(input("Enter Your age: "))

print(name)
print(num)

n1=int(input("enter number 1:"))
n2=int(input("enter number 2:"))

x=n1+n2
print(x)
