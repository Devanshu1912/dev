import math
radius=float(input("Enter radius of circle:"))
area=math.pi*radius*radius
print("Area of circle is:",area)
