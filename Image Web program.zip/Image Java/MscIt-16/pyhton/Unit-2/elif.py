
var1 = ("Riyaz")

if(type(var1)==int):
    print("variable is integer")
elif(type(var1)==float):
    print("variable is Float")
elif(type(var1)==complex):
    print("variable is Complex")
elif(type(var1)==bool):
    print("variable is Boolean")
elif(type(var1)==str):
    print("variable is string")
elif(type(var1)==tuple):
    print("variable is tupple")
elif(type(var1)==dict):
    print("variable is Dictionaries")
elif(type(var1)==list):
    print("variable is List")
else:
    print("variable is Unknown")

