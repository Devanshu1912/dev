age=int(input("Enter Your Age: "))

if(age>=11):
    print("you are eligible for ticket")
    
    if(age <= 20 or age >= 60):
        print("ticket amount is 12$")
    else:
        print("ticket amount is 30$")
else:
    print("you are not eligible for ticket")
