num1 = int(input("Enter Start number:"))
num2 = int(input("Enter End number: "))

print("Even numbers between",num1,"and",num2,"are:")
for num in range(num1,num2+1):
    if  num%2==0:
        for i in range(num,2):
            if num%2 !=0:
                continue
            else:
                print(num,"is Even Number")
    
