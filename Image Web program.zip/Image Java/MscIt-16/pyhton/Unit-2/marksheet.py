m1=int(input("Enter Marks of Java: "))
m2=int(input("Enter Marks of Python: "))
m3=int(input("Enter Marks of Web: "))
tot=m1+m2+m3
print(tot)
per=tot/3
print(per)

if(per<100 and per>=80):
    print("Your Grade is A")
elif(per<80 and per>=70):
    print("Your Grade is B")
elif(per<70 and per>=50):
    print("Your Grade is C")
elif(per<50 and per>=33):
    print("Your Grade is D")
else:
    print("Your are fail")
