import java.util.*;
public class prg25 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String str = sc.nextLine();

       
        int length = str.length();
        System.out.println("Length of the string: " + length);
 
        String upperStr = str.toUpperCase();
        System.out.println("Uppercase: " + upperStr);
        
        String lowerStr = str.toLowerCase();
        System.out.println("Lowercase: " + lowerStr);

        System.out.print("Enter a substring to check: ");
        String substr = sc.nextLine();
        boolean contains = str.contains(substr);
        System.out.println("Contains \"" + substr + "\": " + contains);

        System.out.print("Replace a substring");
        System.out.print("Enter a substring to replace: ");
        String toReplace = sc.nextLine();
        System.out.print("Enter the new substring: ");
        String newSubstr = sc.nextLine();
        String replacedStr = str.replace(toReplace, newSubstr);
        System.out.println("After replacement: " + replacedStr);

        System.out.print("Split the string by spaces");
        String[] parts = str.split(" ");
        System.out.println("Splitted parts:");
        for (String part : parts) {
            System.out.println(part);
        }

        sc.close();
    }
}