import java.util.Scanner;
public class prg15
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Principal amount: ");
        long p = sc.nextInt();
        System.out.print("Enter Rate of interest: ");
        long r = sc.nextInt();
        System.out.print("Enter Time (in years): ");
        long n = sc.nextInt();
        
        long si = (p * r * n) / 100;
        System.out.println("The Simple Interest is: " + si);
    }
}