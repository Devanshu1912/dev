import java.util.Scanner;
public class prg11 {
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first number: ");
        int num1 = sc.nextInt();
        System.out.print("Enter second number: ");
        int num2 = sc.nextInt();

        System.out.println("Arithmetic Operators:");
        System.out.println("Addition: " + (num1 + num2));
        System.out.println("Subtraction: " + (num1 - num2));
        System.out.println("Multiplication: " + (num1 * num2));
        System.out.println("Division: " + (num1 / num2));
        System.out.println("Modulus: " + (num1 % num2));

        System.out.println("\nRelational Operators:");
        System.out.println("Equal to: " + (num1 == num2));
        System.out.println("Not equal to: " + (num1 != num2));
        System.out.println("Greater than: " + (num1 > num2));
        System.out.println("Less than: " + (num1 < num2));
        System.out.println("Greater than or equal to: " + (num1 >= num2));
        System.out.println("Less than or equal to: " + (num1 <= num2));

        boolean a = true, b = false;
        System.out.println("\nLogical Operators:");
        System.out.println("Logical AND: " + (a && b));
        System.out.println("Logical OR: " + (a || b));
        System.out.println("Logical NOT: " + (!a));

        System.out.println("\nBitwise Operators:");
        System.out.println("Bitwise AND: " + (num1 & num2));
        System.out.println("Bitwise OR: " + (num1 | num2));
        System.out.println("Bitwise XOR: " + (num1 ^ num2));
        System.out.println("Bitwise NOT of first number: " + (~num1));
        System.out.println("Left Shift first number by 1: " + (num1 << 1));
        System.out.println("Right Shift first number by 1: " + (num1 >> 1));

        int assignNum = num1;
        System.out.println("\nAssignment Operators:");
        System.out.println("Initial value: " + assignNum);
        assignNum += num2;
        System.out.println("After += : " + assignNum);
        assignNum -= num2;
        System.out.println("After -= : " + assignNum);
        assignNum *= num2;
        System.out.println("After *= : " + assignNum);
        assignNum /= num2;
        System.out.println("After /= : " + assignNum);
        assignNum %= num2;
        System.out.println("After %= : " + assignNum);
        assignNum &= num2;
        System.out.println("After &= : " + assignNum);
        assignNum |= num2;
        System.out.println("After |= : " + assignNum);
        assignNum ^= num2;
        System.out.println("After ^= : " + assignNum);
        assignNum <<= 1;
        System.out.println("After <<= : " + assignNum);
        assignNum >>= 1;
        System.out.println("After >>= : " + assignNum);
        sc.close();
    }
}