import java.util.Scanner;
public  class prg2 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Number to check even or odd:");
        int num = sc.nextInt();
        if(num %2 ==0)
        {
            System.out.print(num + "  is Even Number");
        }
        else
        {
            System.out.print(num +" is odd number");
        }
    }
    
}
