import java.util.*;
 public class prg14 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);       
        System.out.print("Enter your name: ");
        String name = sc.nextLine();        
        System.out.print("Enter your age: ");
        int age = sc.nextInt();
        sc.nextLine();        
        System.out.print("Enter your address: ");
        String add = sc.nextLine();        
        System.out.print("Enter your phone number: ");
        String pno = sc.next();        
        System.out.println("\nPersonal Data:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Address: " + add);
        System.out.println("Phone Number: " + pno);       
        sc.close();
    }
}
