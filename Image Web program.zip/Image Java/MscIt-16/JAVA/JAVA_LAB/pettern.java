import java.util.*;

public class PatternCustom {
    public static void main(String[] args) {
        int n = 5; // you can change n

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (i == 4 || i == 5) {
                    // last two rows all stars
                    System.out.print("*");
                } 
                else if (i == 3 && j == (n / 2) + 1) {
                    // 3rd row middle skip
                    System.out.print(" ");
                } 
                else if (i == 1 || i == n || j == 1 || j == n || i == j || j == (n - i + 1)) {
                    // border or diagonal
                    System.out.print("*");
                } 
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
