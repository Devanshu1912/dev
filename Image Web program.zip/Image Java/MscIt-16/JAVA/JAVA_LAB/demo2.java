import java.util.*;
import java.util.random.*;
public class demo2 {
    
    public static void main (String[] args){
        Scanner a = new Scanner(System.in);
        System.out.print("Enter first value :");
        int num1 = a.nextInt();
        System.out.print("Enter second value: ");
        int num2 = a.nextInt();
       
      
        if (num1 >= num2)
        {
            System.out.print("Enter Number Less than "+num2);
            return;
        }
        Random random = new Random();
        System.out.println("10 random numbers between " + num1 + " and " + num2 + ":");
        for (int i = 0; i < 10; i++){
           int  numbers = random.nextInt((num1 - num2) + 1) + num1;
           System.out.print(numbers + " ");
        }
    }

 }