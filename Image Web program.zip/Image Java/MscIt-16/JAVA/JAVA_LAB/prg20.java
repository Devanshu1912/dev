import java.util.*;
public class prg20 {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Please provide a string as a command line argument.");
            return;
        }
        String str = args[0];
        String reverse = new StringBuilder(str).reverse().toString();

        if (str.equals(reverse)) {
            System.out.println("The string \"" + str + "\" is a Palindrome.");
        } else {
            System.out.println("The string \"" + str + "\" is not a Palindrome.");
        }
    }
}