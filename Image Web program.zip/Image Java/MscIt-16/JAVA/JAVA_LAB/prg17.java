import java.util.*;
public class prg17 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Student Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Roll Number: ");
        int rollNumber = sc.nextInt();
        System.out.print("Enter Marks of JAVA: ");
        int m1 = sc.nextInt();
        System.out.print("Enter Marks of PYTHON: ");
        int m2 = sc.nextInt();
        System.out.print("Enter Marks of JAVA SCRIPT: ");
        int m3 = sc.nextInt();
        
        int total = m1+m2+m3;
        double per = (total / 300.0) * 100;
        
        System.out.println("\nMarksheet");
        System.out.println("----------------------------");
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Subject 1: " + m1);
        System.out.println("Subject 2: " + m2);
        System.out.println("Subject 3: " + m3);
        System.out.println("Total Marks: 300");
        System.out.println("Obtained Marks: " + total);
        System.out.printf("Percentage: %.2f%%\n", per);
        System.out.println("----------------------------");
        
        if (per<100 && per >= 90) 
        {
            System.out.println("Grade: A");
        } 
        else if (per <= 90 && per >= 80) 
        {
            System.out.println("Grade: B");
        } 
        else if (per <= 80 && per >= 70)
        {
            System.out.println("Grade: c");
        } 
        else if (per >= 70 && per >= 60) 
        {
            System.out.println("Grade: D");
        } 
        else if (per >= 60 && per >= 33) 
        {
            System.out.println("Grade: D");
        } 
        else 
        {
            System.out.println("You are Fail");
        }
    }
}