public class prg18 {
    public static void main(String[] args) 
    {
       
        int width1 = 110, height1 = 20, depth1 = 15;
        int volume1 = width1 * height1 * depth1;
        System.out.println("Volume of Box 1: " + volume1);


        int width2 = 23, height2 = 6, depth2 = 9;
        int volume2 = width2 * height2 * depth2;
        System.out.println("Volume of Box 2: " + volume2);
    }
}