public class prg16_2 
{
    public static void main(String[] args) 
    {
        int rows = 3;
        int cols = 5;
        for(int i = 0; i < rows; i++) 
        {
            for(int j = 0; j < cols; j++) 
            {
              if(i==0)
              {
                System.out.print(" *");
              }
              else if(i==1)
              {
                if(j==0 || j==1 || j==3 || j==4)
                {
                    System.out.print(" *");
                }
                else
                {
                    System.out.print("  ");
                }
              }
              else if(i==2)
              {
                if(j==0 || j==4)
                {
                    System.out.print(" *");
                }
                else
                {
                    System.out.print("  ");
                }
              }
            }
            System.out.println();
        }
    }
}
