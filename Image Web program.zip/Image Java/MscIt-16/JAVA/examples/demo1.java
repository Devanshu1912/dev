import java.util.Random;
import java.util.Scanner;

public class demo1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter minimum value: ");
        int min = scanner.nextInt();
        System.out.print("Enter maximum value: ");
        int max = scanner.nextInt();

        if (min > max) {
            System.out.println("Minimum should be less than or equal to maximum.");
            return;
        }

        Random rand = new Random();
        System.out.println("10 random numbers between " + min + " and " + max + ":");
        for (int i = 0; i < 10; i++) {
            int randomNum = rand.nextInt((max - min) + 1) + min;
            System.out.println(randomNum);
        }
    }
}