import java.util.Scanner;

public class sumofall 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
          int[] arr =  new int[10];
          int evensum = 0;
          int oddsum = 0;
          int sumall = 0;
          for (int i = 0; i < arr.length; i++) 
          {
            System.out.print("Enter number " + (i + 1) + ": ");
            arr[i] = sc.nextInt();
            sumall += arr[i];
            if (arr[i] % 2 == 0) 
            {
                evensum += arr[i];
            } 
            else 
            {
                oddsum += arr[i];
            }
        }
        System.out.println("Sum of even numbers: " + evensum);
        System.out.println("Sum of odd numbers: " + oddsum);
        System.out.println("Sum of all numbers: " + sumall);
}
}