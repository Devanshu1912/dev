import java.util.Scanner;

public class demo2 {

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your name: ");
        String name = sc.nextLine();
        System.out.println("Enter your Age: ");
        int  age = sc.nextInt();
        System.out.println("Hello " + name + "!");
        System.out.println("Your age is " + age + " years.");
        sc.close();
    }
}