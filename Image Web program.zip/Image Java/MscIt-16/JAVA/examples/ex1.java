// Palindrome checker: takes a string from command-line arguments and reports whether it's a palindrome.
// Normalization: removes non-alphanumeric characters and ignores case.
public class ex1 {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java ex1 <string to check>");
            System.out.println("If the string contains spaces, quote it: \"A man a plan a canal Panama\"");
            return;
        }

        // Combine all command-line arguments into one string (so both quoted and unquoted multi-word inputs work)
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            if (i > 0) sb.append(' ');
            sb.append(args[i]);
        }

        String input = sb.toString();

        // Normalize: remove non-alphanumeric characters and convert to lower-case
        String normalized = input.replaceAll("[^A-Za-z0-9]", "").toLowerCase();

        if (normalized.length() == 0) {
            System.out.println("No alphanumeric characters to check in: \"" + input + "\"");
            return;
        }

        // Check palindrome with two-pointer technique
        int i = 0, j = normalized.length() - 1;
        boolean isPalindrome = true;
        while (i < j) {
            if (normalized.charAt(i) != normalized.charAt(j)) {
                isPalindrome = false;
                break;
            }
            i++; j--;
        }

        if (isPalindrome) {
            System.out.println('"' + input + '"' + " -> is a palindrome");
        } else {
            System.out.println('"' + input + '"' + " -> is NOT a palindrome");
        }
    }
}
