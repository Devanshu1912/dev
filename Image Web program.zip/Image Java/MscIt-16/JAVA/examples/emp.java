import java.util.*;
class emp
{   Scanner sc = new Scanner(System.in);
    int empno;
    String ename;
    double basic, hra, da, pf, it,sal,ta;

    void getdata()
    {
        System.out.print("Enter Employee Number:");
        empno = sc.nextInt();
        System.out.println("Enter Employee Name:");
        ename = sc.next();
        System.out.println("Enter Employee Basic Salary:");
        basic = sc.nextDouble();
    }
    void calculate()
    {
        hra = 0.10 * basic;
        da = 0.55 * basic;
        pf = 1800;
        it = 0.5 * basic;
        ta=0.2*basic;
        sal = basic+hra+da+ta-pf-it;
    }
    void display()
    {
        System.out.println("Employee Number: " + empno);
        System.out.println("Employee Name: " + ename);
        System.out.println("Employee Basic Salary: " + basic);
        System.out.println("Employee HRA: " + hra);
        System.out.println("Employee DA: " + da);
        System.out.println("Employee TA: " + ta);
        System.out.println("Employee PF: " + pf);
        System.out.println("Employee IT: " + it);
        System.out.println("Employee Net Salary: " + sal);
    }
    public static void main(String[] args) 
    {
        emp e = new emp();
        e.getdata();
        e.calculate();
        e.display();
    }

}

