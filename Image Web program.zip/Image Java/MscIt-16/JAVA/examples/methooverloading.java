import java.util.*;
class sum{
    int x = 10;
    int y = 5;
    int add;
    void sum(int x, int y)
    {
         add = x + y;
    }
    void getadd()
    {
        System.out.print(add);
    }
}
public class methooverloading {
    public static void main(String[] args) {
        
    
    sum s1 = new sum();
    s1.getadd();
    }
}
