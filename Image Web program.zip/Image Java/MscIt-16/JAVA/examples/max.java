import java.util.Scanner;

public class max {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number:1 ");
        int n1 = sc.nextInt();
        System.out.print("Enter a number:2 ");
        int n2 = sc.nextInt();
        if(n1>n2)
        {
            System.out.println(n1 + " is max ");
        }
        else
        {
            System.out.println(n2 + " is max ");
        }
       
    }
}
