import java.util.*;

class country
{
    Scanner c = new Scanner(System.in);
    String name;
    int cid;
    
    void setcountry()
    {
        System.out.print("Enter Country Code: ");
        cid = c.nextInt();
        System.out.print("Enter Country Name: ");
        name = c.nextLine();
    }
    void getcountry()
    {
        System.out.print("Country Code is: "+cid);
        System.out.print("Country Name is: "+name);
    }
}
class state extends country
{
    int sid;
    String sname;
    
    void setstate()
    {
        super.setcountry();
        System.out.print("Enter State Code: ");
        sid = c.nextInt();
        System.out.print("Enter State Name: ");
        sname = c.nextLine();
    }
    void getstate()
    {
        System.out.print("Country Code is: "+sid);
        System.out.print("Country Name is: "+sname);
    }
}
public class contry {
    country c1 = new country();
    c1.setcountry();
    c1.getcricketer();

}