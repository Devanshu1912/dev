import java.util.*;

class cricketer{
    Scanner sc = new Scanner(System.in);
    int cid;
    String cname,country;
    void setcricketr()
    {
        System.out.print("Enter Cricketer ID: ");
        cid = sc.nextInt();
        System.out.print("Enter Cricketer Name: ");
        cname = sc.next();
        System.out.print("Enter Country Name: ");
        country = sc.next();
    }
    void getcricketer()
    {
        System.out.print("Cricketer ID is: " +cid);
        System.out.print("Cricketer Name is: "+cname);
        System.out.print("Cricketer Country is: "+country);
    }
    class bowler extends cricketer
    {
        int matches,wickets;
        float avg;
        void setbowler()
        {
            super.setcricketr();
            System.out.print("Enter The Number of Matches: ");
            matches = sc.nextInt();
            System.out.print("Enter The Number of Wickets Taken by Bowler: ");
            wickets = sc.nextInt();
            System.out.print("Enter The Average of Bowler: ");
            avg = sc.nextInt();
        }
      
        void getbowler()
        {
            super.getcricketer();
            System.out.println("Details Of Bowler:");
            System.out.println("Total matches:"+matches);
            System.out.println("Total wickets: "+wickets);
            System.out.println("Average Of Bowler: "+avg);
        }
        
    }
    class batsman extends cricketer
    {
        int matches,runs;
        float runrate;

        void setbatsman()
        {
            super.setcricketr();
            System.out.print("Enter The number of Matches: ");
            matches = sc.nextInt();
            System.out.print("Enter the Run of Batsman: ");
            runs = sc.nextInt();
            System.out.print("Enter the Runrate: ");
            runrate = sc.nextInt();
        }
       
        void getbatsman()
        {
            super.getcricketer();
            System.out.println("Details Of Batsman: ");
            System.out.println("Total Matches: "+matches);
            System.out.println("Total Runs: "+runs);
            System.out.println("Runrate of Batsman: "+runrate);
        }
    }
}
public class herarInherit {
   public static void main(String[] args) 
{
    cricketer c = new cricketer();
    cricketer.bowler b1 = c.new bowler();
    b1.setbowler();
    b1.getbowler();
    cricketer.batsman b2 = c.new batsman();
    b2.setbatsman();
    b2.getbatsman();
}
}
