import java.util.Scanner;
import java.util.Arrays;
public class arracending {
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
          int[] arr =  new int[5];
          for (int i = 0; i < arr.length; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            arr[i] = sc.nextInt();
    }
        Arrays.sort(arr);
        System.out.println("Array in ascending order: " + Arrays.toString(arr));
}
}
