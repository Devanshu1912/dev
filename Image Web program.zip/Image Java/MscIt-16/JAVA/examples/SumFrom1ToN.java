import java.util.Scanner;

public class SumFrom1ToN 
    {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a number: ");
            int n = sc.nextInt();
            int total = 0;
            for (int i = 1; i <= n; i++) {
                total += i;
            }
            System.out.println("Sum from 1 to " + n + " is:  " + total);
    }
}