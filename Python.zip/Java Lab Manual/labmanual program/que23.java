public class que23 {
    static int instanceCount = 0;
    int id;
    
    static {
        System.out.println("Static block executed: Class loaded.");
    }
    
    public que23() {
        instanceCount++;
        this.id = instanceCount;
        System.out.println("Instance created with ID: " + id);
    }
    
    public static void showInstanceCount() {
        System.out.println("Total instances created: " + instanceCount);
    }
    
    public void showId() {
        System.out.println("This instance's ID: " + id);
    }   
    public static void main(String[] args) {
        que23.showInstanceCount(); 
        que23 obj1 = new que23();
        que23 obj2 = new que23();
        que23.showInstanceCount();
        obj1.showId(); 
        obj2.showId(); 
    }
}

