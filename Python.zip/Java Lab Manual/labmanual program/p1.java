public class p1 {
    public static void main(String[] args) 
    {
        if(System.out.printf("Devanshu Jogani") == null){

        }
    }
}
