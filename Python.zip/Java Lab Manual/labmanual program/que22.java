class Animal {
    String name;
        
    Animal(String name) {
        this.name = name;
        System.out.println("Animal constructor called: " + name);
    }
    
    void eat() {
        System.out.println(name + " is eating.");
    }
}

class Dog extends Animal {
    String breed;
   
    Dog(String name, String breed) {
        super(name);  
        this.breed = breed;
        System.out.println("Dog constructor called: " + breed);
    }
    
    void eat() {
        super.eat(); 
        System.out.println(name + " (a " + breed + ") is barking after eating.");
    }
}

public class que22 {
    public static void main(String[] args) {
        Dog dog = new Dog("Buddy", "Golden Retriever");
        dog.eat();
    }
}

