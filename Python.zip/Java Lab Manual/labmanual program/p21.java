public class p21 {
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Please provide 3 Name: ");
            return;
        }
        String name1 = args[0];
        String name2 = args[1];
        String name3 = args[2];

      
        System.out.println("First Name: " + name1);
        System.out.println("Second Name: " + name2);
        System.out.println("Third Name: " + name3);

    }
}