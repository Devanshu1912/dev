import java.util.Scanner;

public class p6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a Number : ");
        int n = scanner.nextInt();
        int original = n;
        int sum = 0;
        int nums = String.valueOf(n).length();

        while (n != 0) {
            int num = n % 10;
            sum += Math.pow(num, nums);
            n /= 10;
        }

        if (sum == original) {
            System.out.println(original + " is an Armstrong number.");
        } else {
            System.out.println(original + " is not an Armstrong number.");
        }

        scanner.close();
    }
}
