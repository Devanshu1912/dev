import java.util.Scanner;

public class p17 {

    public static void main(String[] args) {
        
         Scanner s1 = new Scanner(System.in);

        System.out.print("Enter Your Name : ");
        String name = s1.nextLine();
        System.out.print("Enter Your Roll Number : ");
        String rno = s1.nextLine();

        System.out.print("Enter the marks of all subjects ");
        System.out.print("\n Enter Your Maths marks : ");
        int math = s1.nextInt();
        System.out.print("Enter Your python marks : ");
        int python = s1.nextInt();
        System.out.print("Enter Your java marks : ");
        int java = s1.nextInt();
        System.out.print("Enter Your web Programming marks : ");
        int web = s1.nextInt();

        int total = math + python + java + web;
        int per = total / 4;

        String grade;
        if (per >= 90) {
            grade = "A+";
        } else if (per >= 80) {
            grade = "A";
        } else if (per >= 70) {
            grade = "B+";
        } else if (per >= 60) {
            grade = "B";
        } else if (per >= 50) {
            grade = "C";
        } else if (per >= 40) {
            grade = "D";
        } else {
            grade = "F";
        }



        System.out.println("\n\n -------Student Marksheet-------");
        System.out.println("Name : " + name);
        System.out.println("Roll No. : " + rno);
        System.out.println("Maths Marks : " + math);
        System.out.println("Python Marks : " + python);
        System.out.println("Java Marks : " + java);
        System.out.println("Web Programming Marks : " + web);
        System.out.println("Total Marks : " + total);
        System.out.println("Percentage(%) : " + per+"%");
        System.out.println("Grade : " + grade);

        s1.close();
    }
    

}
