import java.util.Scanner;
public class voting {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the age: ");
        int age = sc.nextInt();

        if (age >=18){
            System.out.println("Eligible for voting.");
        }
        else{
            System.out.println("Not Eligible for voting.");

        }
        sc.close();
    }
}
