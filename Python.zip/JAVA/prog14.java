 import java.util.Scanner;
 
 public class prog14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your full name: ");
        String name = scanner.nextLine();

        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter your email address: ");
        String email = scanner.nextLine();

        System.out.print("Enter your phone number: ");
        String phone = scanner.nextLine();

        System.out.println("\n--- Personal Data ---");
        System.out.println("Name       : " + name);
        System.out.println("Age        : " + age);
        System.out.println("Email      : " + email);
        System.out.println("Phone      : " + phone);

        scanner.close();
    }
}
