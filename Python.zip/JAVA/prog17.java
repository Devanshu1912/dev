import java.util.Scanner;

public class prog17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Roll Number: ");
        String rollNumber = scanner.nextLine();

        int subjects = 5;
        String[] subjectNames = {"Mathematics", "Physics", "Chemistry", "English", "Computer Science"};
        int[] marks = new int[subjects];

        for (int i = 0; i < subjects; i++) {
            System.out.print("Enter marks for " + subjectNames[i] + " (out of 100): ");
            marks[i] = scanner.nextInt();

            while (marks[i] < 0 || marks[i] > 100) {
                System.out.print("Invalid marks! Please enter marks between 0 and 100 for " + subjectNames[i] + ": ");
                marks[i] = scanner.nextInt();
            }
        }

        int totalMarks = 0;
        for (int mark : marks) {
            totalMarks += mark;
        }
        double percentage = (totalMarks * 100.0) / (subjects * 100);

        String grade;
        if (percentage >= 90) {
            grade = "A+";
        } else if (percentage >= 80) {
            grade = "A";
        } else if (percentage >= 70) {
            grade = "B+";
        } else if (percentage >= 60) {
            grade = "B";
        } else if (percentage >= 50) {
            grade = "C";
        } else if (percentage >= 40) {
            grade = "D";
        } else {
            grade = "F";
        }

        System.out.println("\n------------------- Marksheet -------------------");
        System.out.println("Student Name : " + name);
        System.out.println("Roll Number  : " + rollNumber);
        System.out.println("-------------------------------------------------");
        System.out.printf("%-20s %10s\n", "Subject", "Marks");
        System.out.println("-------------------------------------------------");
        for (int i = 0; i < subjects; i++) {
            System.out.printf("%-20s %10d\n", subjectNames[i], marks[i]);
        }
        System.out.println("-------------------------------------------------");
        System.out.printf("%-20s %10d\n", "Total Marks", totalMarks);
        System.out.printf("%-20s %9.2f%%\n", "Percentage", percentage);
        System.out.printf("%-20s %10s\n", "Grade", grade);
        System.out.println("-------------------------------------------------");

        scanner.close();
    }
}
