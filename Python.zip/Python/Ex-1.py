my_list1=[5,12,13,14]
print(my_list1)
