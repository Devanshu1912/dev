print("Devanshu Jogani")

print("This is a backslash (\\) mark.")
print("This is a tab \t Key.")
print("These are \'single quotes\'")
print("These are \"double quotes\"")
print("This is a new line\n new line")
