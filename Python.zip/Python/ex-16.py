
print("Devanshu Jogani")

tup4 = ("Red", "Black", 2000, 12.12)
print(tup4)

print(tup4[0])

tup4[0] = "White"
print(tup4[0])
