print("Devanshu Jogani")

# Tuple


tup1 = (0, -1, 12, 212.23, 100)
type(tup1)

print(tup1)

tup2 = ('Red', 'Black', 2000, "White");
print(tup2)

tup3 = "a1", "b1", "c1", "d1";
type(tup3)

print(tup3)

#



empty_tup1 =()
print(empty_tup1)

single_tup1 = (100,)
print(single_tup1)




