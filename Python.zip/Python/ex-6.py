
#same variable reassign value


x=100
print(x)
x = "Python"
print(x)
