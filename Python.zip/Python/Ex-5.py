print("Devanshu Jogani")
#many value at the same time 

x,y,z = 1,2,"abcd"
print(x)
print(y)
print(z)
