x = y = z = 1

print(x)
print(y)
print(z)

#multiple assignment
