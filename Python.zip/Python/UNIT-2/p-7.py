print("Devanshu Jogani")


# create a string
s = 'Python'


# create a list
l=['javaScript','jQuery','Python']


# in operator is used to replace various expression that use the "or" operator

if s in l:
    print(s+' Tutorial')


# Alternate if statement with "or" operator

if s == 'javaScript' or s == 'jQuery' or s == 'Python':
    print(s + ' Tutorial')

