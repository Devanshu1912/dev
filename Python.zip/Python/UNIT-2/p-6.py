print("Devanshu Jogani")

#Use of "and" operator in an if statement


x = False
y = True

if x and y:
    print("Both x and y are True")
else:
    print("x is False or y is False or both x and y are False")
          
