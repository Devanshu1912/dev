print("Devanshu Jogani")

#create a integer

x = 20
print(x)


#uses the "Not" operator to reverse the result of the logical expression

if not x == 50:
    print('The value of x is different from 50')
else:
    
