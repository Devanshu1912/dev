print("Devanshu Jogani")


# input & print Function

xString=input("Enter a number:")
x=int(xString)
y=x+2
print(y)
