print("Devanshu")
print("Jogani")

print("Devanshu");print("Jogani")

