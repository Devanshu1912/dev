
print("Devanshu Jogani")

tup4 = ("Red", "Black", 2000, 12.12)
print(tup4)

print(tup4[0])
print(tup4[3])
print(tup4[4])
