
print("Devanshu Jogani")

# SET


a = [1, 2, 1, 3, 0, 0, 4, 7, 8, 6]
b = [5, 5, 7, 8, 7, 9, 6, 1, 1, 2]

s1 = set(a) # unique numbers in s1
s2 = set(b) # unique numbers in s2

s1      
s2      

s1 - s2     # number is s1 but not in s2
s1 | s2     # numbers in either s1 or s2
s1 & s2     # numbers in both s1 and s2
s1 ^ s2     # numbers in s1 or s2 but not both


# Python Dictionary

pd = {"Class":'V', "Section":'A', "Roll_no":12}

print(pd["Class"])
print(pd["Section"])
print(pd["Roll_no"])
print(pd)
