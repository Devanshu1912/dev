
# if else statement

x = int(input("Enter a number:")
    if x%2 == 0:
        print("This is a even number")
    else:
        print("This is a odd number")       
