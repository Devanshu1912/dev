# if statement

var1 = 100
if var1:
    print("1- Got a true expression value")
    print(var1)

var2 = 0
if var2:
    print("2- Got a true expression value")
    print(var2)
    print("Good bye!")



