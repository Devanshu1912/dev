print("Devanshu Jogani")


# if..elif..else


var1 = ("a","b")

if(type(var1)==int):
    print("Type of the variable is Integer")
elif(type(var1)==float):
    print("Type of the variable is Float")
elif(type(var1)==complex):
    print("Type of the variable is Complex")
elif(type(var1)==bool):
    print("Type of the variable is Bool")
elif(type(var1)==str):
    print("Type of the variable is String")
elif(type(var1)==tuple):
    print("Type of the variable is Tuple")
elif(type(var1)==dict):
    print("Type of the variable is Dictionaries")
elif(type(var1)==list):
    print("Type of the variable is List")
else:
    print("Type of the variable is Unknown")
