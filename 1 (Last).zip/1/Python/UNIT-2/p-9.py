
print("Devanshu Jogani")


# indices start 0 to 3
color_list = ["Red","Blue","Green","Black"]
for c in color_list:
    print(c)
