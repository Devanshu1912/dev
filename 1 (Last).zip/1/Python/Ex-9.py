print("Devanshu Jogani")

a=1452
type(a)
b=(-4587)
type(b)
c=0
type(c)
g=1.03
type(g)
h=-11.23
type(h)
i=.34
type(i)
j=2.12e-10
type(j)
k=5E220
type(k)
x=True
type(x)
y=False
type(y)


