  public class prog16b {
    public static void main(String[] args) {
        int rows = 3;
        int cols = 5;

        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= cols; j++) {
               
                if (i == 1) {
                    System.out.print("* ");
                } else if (i == 2) {
                    if (j == 1 || j == 2 || j == 4 || j == 5) {
                        System.out.print("* ");
                    } else {
                        System.out.print("  ");
                    }
                } else if (i == 3) {
                    if (j == 1 || j == 5) {
                        System.out.print("* ");
                    } else {
                        System.out.print("  ");
                    }
                }
            }
            System.out.println();
        }
    }
}
