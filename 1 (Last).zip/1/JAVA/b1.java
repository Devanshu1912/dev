import java.util.Scanner;

public class b1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter units consumed: ");
        int units = sc.nextInt();
        int cost = units * 8;
        System.out.println("Total bill = " +cost);
        sc.close();
    }
    

    
}
