public class prog16 {
    public static void main(String[] args) {
        int rows = 5;

        int maxWidth = rows * 2 - 1;

        for (int i = 1; i <= rows; i++) {
            int currentWidth = i * 2 - 1;
            int spaces = (maxWidth - currentWidth) / 2;
            for (int s = 0; s < spaces; s++) {
                System.out.print(" ");
            }

            for (int j = 1; j <= i; j++) {
                System.out.print(i);
                if (j < i) {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }
}

