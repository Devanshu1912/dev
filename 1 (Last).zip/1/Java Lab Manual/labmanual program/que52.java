import javax.swing.*;
import java.awt.event.*;

class que52 {
    public static void main(String[] args) {

        JFrame f = new JFrame("Login Form");

        JLabel l1 = new JLabel("Username:");
        JLabel l2 = new JLabel("Password:");
        JLabel msg = new JLabel("");
        JTextField t1 = new JTextField();
        JPasswordField t2 = new JPasswordField();
        JButton b = new JButton("Login");


        l1.setBounds(30, 30, 80, 25);
        t1.setBounds(120, 30, 120, 25);

        l2.setBounds(30, 70, 80, 25);
        t2.setBounds(120, 70, 120, 25);

        b.setBounds(30, 110, 80, 30);
        msg.setBounds(120, 110, 150, 30);

        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String user = t1.getText();
                String pass = new String(t2.getPassword());

                if (user.equals("ISTAR") && pass.equals("ISTAR")) {
                    msg.setText("Login Successfully");
                } else {
                    msg.setText("Invalid Login");
                }
            }
        });


        f.add(l1); f.add(t1);
        f.add(l2); f.add(t2);
        f.add(b);  f.add(msg);

        f.setSize(300, 200);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
