import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class que54 {
    public static void main(String[] args) {

        JFrame f = new JFrame("Color Change App");

        JButton b1 = new JButton("Red");
        JButton b2 = new JButton("Green");
        JButton b3 = new JButton("Blue");
        JButton b4 = new JButton("Yellow");

        b1.setBounds(50, 30, 80, 30);
        b2.setBounds(140, 30, 80, 30);
        b3.setBounds(230, 30, 80, 30);
        b4.setBounds(320, 30, 80, 30);

       
        b1.addActionListener(e -> f.getContentPane().setBackground(Color.RED));
        b2.addActionListener(e -> f.getContentPane().setBackground(Color.GREEN));
        b3.addActionListener(e -> f.getContentPane().setBackground(Color.BLUE));
        b4.addActionListener(e -> f.getContentPane().setBackground(Color.YELLOW));

        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(b4);

        f.setSize(450, 300);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
