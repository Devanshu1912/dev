import java.util.*;

public class p10 {
     public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter first number : ");
        int a = s.nextInt();
        System.out.print("Enter second number : ");
        int b = s.nextInt();
        System.out.print("Enter third number : ");
        int c = s.nextInt();

        int v = (a >= b) ? ((a >= c) ? a:c):((b >= c) ? b:c);

        if(a == b && b == c){
            System.out.println("all number is equal.");
        }else{
            System.out.println(v + " is greater number.");
        }
        s.close();
    }
}
