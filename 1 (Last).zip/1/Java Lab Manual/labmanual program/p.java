public class p {
    public static void main(String[] args) {
         int n = args.length;
        System.out.println("Number of arguments = " + n);

        for (int i = 0; i < args.length; i++) {
            String ordinal = "";
            if (i == 0) ordinal = "First";
            else if (i == 1) ordinal = "Second";
            else if (i == 2) ordinal = "Third";
            else ordinal = (i + 1) + "th";

            System.out.println((i + 1) + ".: " + ordinal + " Student Name is = " + args[i]);
        }
    }
}
