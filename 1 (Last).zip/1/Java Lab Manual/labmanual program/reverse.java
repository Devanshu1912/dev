import java.util.*;

public class reverse {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String str = sc.next();
        StringBuilder sb = new StringBuilder(str);
        sb.reverse();
        System.out.println("Reversed string is: "+sb);
    }
}
