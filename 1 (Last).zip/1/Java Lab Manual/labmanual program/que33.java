public class que33 {
    private double radius;

    public que33() {
        this.radius = 1.0;
    }

    public que33(double radius) {
        this.radius = radius;
    }

    public void calcArea() {
        double area = Math.PI * radius * radius;
        System.out.println("Area of the circle with radius " + radius + " is: " + area);
    }

    public static void main(String[] args) {
        que33 circle1 = new que33();
        circle1.calcArea();
        que33 circle2 = new que33(5.0);
        circle2.calcArea();
    }
}
