import javax.swing.*;
import java.awt.event.*;

class que55 {
    public static void main(String[] args) {

        JFrame f = new JFrame("Student Entry Form");

        JLabel l1 = new JLabel("Student ID:");
        JLabel l2 = new JLabel("Name:");
        JLabel l3 = new JLabel("Department:");
        JLabel l4 = new JLabel("Semester:");
        JLabel l5 = new JLabel("Inserted Student Records:");

        JTextField t1 = new JTextField();
        JTextField t2 = new JTextField();
        JTextField t3 = new JTextField();

        String dept[] = {"MCA", "M.Sc.IT", "BCA", "B.Sc.IT"};
        JComboBox<String> cb = new JComboBox<>(dept);

        JTextArea ta = new JTextArea();
        ta.setEditable(false);

        JButton b = new JButton("Insert");

        
        l1.setBounds(20, 20, 80, 25);
        t1.setBounds(100, 20, 80, 25);

        l2.setBounds(190, 20, 50, 25);
        t2.setBounds(240, 20, 80, 25);

        l3.setBounds(330, 20, 80, 25);
        cb.setBounds(410, 20, 90, 25);

        l4.setBounds(510, 20, 70, 25);
        t3.setBounds(580, 20, 50, 25);

        b.setBounds(640, 20, 80, 25);

        l5.setBounds(640, 60, 180, 25);
        ta.setBounds(200, 60, 420, 200);

       
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ta.append(
                    t1.getText() + "\t" +
                    t2.getText() + "\t" +
                    cb.getSelectedItem() + "\t" +
                    t3.getText() + "\n"
                );

              
                t1.setText("");
                t2.setText("");
                t3.setText("");
            }
        });

    
        f.add(l1); f.add(t1);
        f.add(l2); f.add(t2);
        f.add(l3); f.add(cb);
        f.add(l4); f.add(t3);
        f.add(b);
        f.add(l5);
        f.add(ta);

        f.setSize(850, 330);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
