class Product {
    private String name;
    private String productCode;
    private String manufacturer;

    public Product() {
        this.name = "Unknown";
        this.productCode = "N/A";
        this.manufacturer = "Unknown";
    }

    public Product(String name) {
        this.name = name;
        this.productCode = "N/A";
        this.manufacturer = "Unknown";
    }

    public Product(String name, String productCode, String manufacturer) {
        this.name = name;
        this.productCode = productCode;
        this.manufacturer = manufacturer;
    }

    public String getName() {
        return name;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public void display() {
        System.out.println("Product Name: " + name);
        System.out.println("Product Code: " + productCode);
        System.out.println("Manufacturer: " + manufacturer);
        System.out.println("-------------------");
    }
}

public class que39 {
    public static void main(String[] args) {
        System.out.println("1. Testing default constructor:");
        Product p1 = new Product();
        p1.display();

        System.out.println("2. Testing constructor with name only:");
        Product p2 = new Product("Laptop");
        p2.display();

        System.out.println("3. Testing full constructor:");
        Product p3 = new Product("iPhone 15", "IP15", "Apple");
        p3.display();

        System.out.println("4. Testing setter methods:");
        p3.setName("iPhone 15 Pro");
        p3.setProductCode("IP15P");
        p3.setManufacturer("Apple Inc.");
        p3.display();

        System.out.println("5. Testing getter methods:");
        System.out.println("Name: " + p3.getName());
        System.out.println("Code: " + p3.getProductCode());
        System.out.println("Manufacturer: " + p3.getManufacturer());
    }
}