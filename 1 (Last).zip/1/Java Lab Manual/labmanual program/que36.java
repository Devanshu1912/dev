interface Drawable {
    void draw();          
    default void message() { 
        System.out.println("Drawing from interface");
    }
}

interface Resizable {
    void resize(int width, int height);
}

class Circle implements Drawable {
    @Override
    public void draw() {
        System.out.println("Drawing a Circle");
    }
}

class Rectangle implements Drawable, Resizable {
    @Override
    public void draw() {
        System.out.println("Drawing a Rectangle");
    }

    @Override
    public void resize(int width, int height) {
        System.out.println("Resizing rectangle to " + width + "x" + height);
    }
}

public class que36 {
    public static void main(String[] args) {
        Drawable d1 = new Circle();
        Drawable d2 = new Rectangle();
        
        d1.draw();      
        d2.draw();     
        d2.message();   

        Resizable r = new Rectangle();
        r.resize(100, 50);
        
        Drawable[] shapes = {new Circle(), new Rectangle()};
        for (Drawable shape : shapes) {
            shape.draw();
        }
    }
}