import java.util.*;

public class p11 {
    public static void main(String[] args) {
        Scanner s1 = new Scanner(System.in);

      System.out.print("Enter first number : ");
      int a = s1.nextInt();
      System.out.print("Enter second number : ");
      int b = s1.nextInt();

      System.out.println("Arithmetic Operator");
      System.out.println("Addition : " + (a+b));
      System.out.println("Subtraction : " + (a-b));
      System.out.println("Multiplication : " + (a*b));
      System.out.println("Division : " + (a/b));
      System.out.println("Moduls : " + (a%b));
      

      System.out.println("\n Relational Operator");
      System.out.println("Equal to : " + (a==b));
      System.out.println("Not equal to : " + (a!=b));
      System.out.println("Greater than : " + (a>b));
      System.out.println("Less than : " + (a<b));
      System.out.println("Greater than or equal to : " + (a>=b));
      System.out.println("Less than or equal to : " + (a<=b));


      boolean a1 = true, b1 = false;
      System.out.println("\n Logical Operator");
      System.out.println("Logical AND : " + (a1&&b1));
      System.out.println("Logical OR : " + (a1||b1));
      System.out.println("Logical NOT : " + (!a1));


      System.out.println("\n Bitwise Operator");
      System.out.println("Bitwise AND : " + (a&b));
      System.out.println("Bitwise OR : " + (a|b));
      System.out.println("Bitwise XOR : " + (a^b));
      System.out.println("Bitwise NOT a first number : " + (~a));
      System.out.println("Left shift first number by 1 : " + (a<<1));
      System.out.println("Right shift first number by 1 : " + (a>>1));


      int Assign = a;
      System.out.println("\n Assignment Operator");
      System.out.println("Initial value : " + Assign);
      Assign += b;
      System.out.println("After += : " + Assign);
      Assign -= b;
      System.out.println("After -= : " + Assign);
      Assign *= b;
      System.out.println("After *= : " + Assign);
      Assign /= b;
      System.out.println("After /= : " + Assign);
      Assign %= b;
      System.out.println("After %= : " + Assign);
      Assign &= b;
      System.out.println("After &= : " + Assign);
      Assign |= b;
      System.out.println("After |= : " + Assign);
      Assign ^= b;
      System.out.println("After ^= : " + Assign);
      Assign <<= b;
      System.out.println("After <<= : " + Assign);
      Assign >>= b;
       System.out.println("After >>= : " + Assign);
    
       
      s1.close();

    }
    
}
