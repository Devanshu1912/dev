import java.util.Scanner;

public class emp {
    Scanner sc = new Scanner(System.in);
    int empno;
    String name;
    double basic,salary,hra,it,pf,da,ta;
   
    void getdata(){
        System.out.println("Enter Employee Number : ");
        empno = sc.nextInt();
        System.out.println("Enter Employee Name : ");
        name = sc.next();
        System.out.println("Enter Basic Salary : ");
        basic = sc.nextDouble();
    }

    void calc(){
        hra = 0.10*basic;
        da = 0.55*basic;
        ta = 0.02*basic;
        pf = 1500;
        it = 0.05*basic;
        salary = basic+hra+da+ta-pf-it;
    }

    void dispaly(){
        System.out.println("Employee Number : "+empno);
        System.out.println("Employee Name : "+name);
        System.out.println("Basic Salary : "+basic);
        System.out.println("HRA : "+hra);
        System.out.println("IT : "+it);
        System.out.println("PF : "+pf);
        System.out.println("DA : "+da);
        System.out.println("TA : "+ta);
        System.out.println("Net Salary : "+salary);
    }

    public static void main(String[] args) {
 
        emp e = new emp();
        e.getdata();
        e.calc();
        e.dispaly();

    }
}