import java.util.*;

public class p9 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter first number : ");
        int a = s.nextInt();
        System.out.print("Enter second number : ");
        int b = s.nextInt();

        System.out.println("Before swapping: a : " + a + ", b : "+ b);
        a = a + b;
        b = a - b;
        a = a - b;
        System.out.println("After swapping: a : " + a + ", b : "+ b);
        s.close();
    }

}
