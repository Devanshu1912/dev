public class p25 {
   
    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "World";
        String str3 = "hello";

        // Length of a string
        System.out.println("Length of str1: " + str1.length());

        // Concatenation
        System.out.println("Concatenation of str1 and str2: " + str1 + " " + str2);

        // Compare strings (case-sensitive)
        System.out.println("str1 equals str2? " + str1.equals(str2));

        // Compare strings (case-insensitive)
        System.out.println("str1 equals str3 (ignore case)? " + str1.equalsIgnoreCase(str3));

        // Character at a specific index
        System.out.println("Character at index 1 in str1: " + str1.charAt(1));

        // Substring
        System.out.println("Substring of str1 (1 to 4): " + str1.substring(1, 4));

        // Convert to uppercase
        System.out.println("str1 in uppercase: " + str1.toUpperCase());

        // Convert to lowercase
        System.out.println("str2 in lowercase: " + str2.toLowerCase());

        // Check if str1 contains "ll"
        System.out.println("str1 contains 'll'? " + str1.contains("ll"));

        // Replace characters
        System.out.println("str1 after replacing 'l' with 'p': " + str1.replace('l', 'p'));

        // Trim whitespace
        String strWithSpaces = "  Hello World  ";
        System.out.println("Original with spaces: '" + strWithSpaces + "'");
        System.out.println("After trim: '" + strWithSpaces.trim() + "'");

        // Split string by space
        String[] parts = str2.split("o");
        System.out.print("Splitting 'World' by 'o': ");
        for (String part : parts) {
            System.out.print("'" + part + "' ");
        }
        System.out.println();

        // Index of a character
        System.out.println("Index of 'o' in str2: " + str2.indexOf('o'));

        // Last index of a character
        System.out.println("Last index of 'l' in str1: " + str1.lastIndexOf('l'));
    }
}


