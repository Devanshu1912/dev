print("Devanshu Jogani")


# range of sequence of numbers

#range(a)        #stop
#range(a,b)      #start,stop
#range(a,b,c)    #start,stop,step


for a in range(4):
    print(a)
    

for a in range(2,7):
    print(a)



for a in range(2,19,5):
    print(a)


myString = input("Enter a number:")
myint = int(myString)

for x in range(0,myint,1):
    print(x)

