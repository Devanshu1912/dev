print("Devanshu Jogani")

#   slicing tuple

tup2 = ('Red', 'Black', 2000, "White");

print(tup2[0:2])
print(tup2[1:2])
print(tup2[1:-2])
print(tup2[:3])
