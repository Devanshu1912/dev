print("Devanshu Jogani")

#swap variable

x = 10
y = 20
print(x)
print(y)
x,y = y,x
print(x)
print(y)

