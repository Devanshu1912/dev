print("Devanshu Jogani")

string1 = "PYTHON TUTORIAL"

print(string1[0])
print(string1[-15])
print(string1[14])
print(string1[-1])
print(string1[4])
print(string1[-11])
print(string1[16])
