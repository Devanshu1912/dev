print("Devanshu Jogani")


# Arithmetic Operators

a=21
b=10
c=0

c=a+b
print("Line 1- value of c is ", c)

c=a-b
print("Line 2- value of c is ", c)

c=a*b
print("Line 3- value of c is ", c)

c=a/b
print("Line 4- value of c is ", c)

c=a%b
print("Line 5- value of c is ", c)

a=2
b=3
c=a**b
print("Line 6- value of c is ", c)

a=10
b=5
c=a//b
print("Line 7- value of c is ", c)



# Comparison Operators


a = 21
b = 10
if(a == b):
    print("Line 1- a is equal to b")
else:
    print("Line 1- a is not equal to b")

if(a != b):
    print("Line 2- a is not equal to b")
else:
    print("Line 2- a is equal to b")

if(a < b):
    print("Line 3- a is less than b")
else:
    print("Line 3- a is not less than b")

if(a > b):
    print("Line 4- a is greater than b")
else:
    print("Line 4- a is not greater than b")

    
a,b=b,a     # values of a and b swaped. a becomes 10, b becomes 21


if(a <= b):
    print("Line 5- a is either less than or equal to b")
else:
    print("Line 5- a is not neither less than nor equal to b")

if(b >= a):
    print("Line 6- a is either greater than or equal to b")
else:
    print("Line 6- a is not neither greater than nor equal to b")
    
    

# Assignment Operators



a = 21
b = 10
c = 0

c = a + b
print("Line 1- value of c is ", c)

c += a
print("Line 2- value of c is ", c)

c *= a
print("Line 3- value of c is ", c)

c /= a
print("Line 4- value of c is ", c)

c = 2

c %= a
print("Line 5- value of c is ", c)

c **= a
print("Line 6- value of c is ", c)

c //= a
print("Line 7- value of c is ", c)



# Membership Operators


a = 10
b = 20
list = [1,2,3,4,5]

if(a in list):
    print("Line 1- a is available in the given list")
else:
    print("Line 1- a is not available in the given list")

if(b not in list):
    print("Line 2- b is not available in the given list")
else:
    print("Line 2- b is available in the given list")

c=b/a

if(c in list):
    print("Line 3- c is available in the given list")
else:
    print("Line 3- c is not available in the given list")


#

