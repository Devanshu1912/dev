print("Devanshu Jogani")


str1="python"
print(str1[3:6])
print(str1[-4:-1])

print(str1[-4:])
