import javax.swing.*;

class que51 {
    public static void main(String[] args) {

        JFrame f = new JFrame(); 
        f.setTitle("ISTAR");
        JLabel l = new JLabel("Welcome in ISTAR!"); 

        f.add(l);                         
        f.setSize(300, 200);              
        f.setVisible(true);               
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
