interface Printable {
    void print();
}

interface Showable {
    void show();
}

class Demo implements Printable, Showable {
    @Override
    public void print() {
        System.out.println("Printing from Printable interface");
    }

    @Override
    public void show() {
        System.out.println("Showing from Showable interface");
    }
}

public class que38 {
    public static void main(String[] args) {
        Demo d = new Demo();
        d.print();
        d.show();
    }
}

