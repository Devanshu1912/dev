import java.util.Scanner;

public class p14 {
    public static void main(String[] args) {
        Scanner s1 = new Scanner(System.in);

        System.out.print("Enter Your Full Name: ");
        String name = s1.nextLine();

        System.out.print("Enter Your age: ");
        int age = s1.nextInt();
        s1.nextLine();

        System.out.print("Enter Your Email Address: ");
        String email = s1.nextLine();

        System.out.print("Enter Your Phone Number: ");
        String phno = s1.nextLine();

        System.out.println("\n\n -------Personal Data-------");
        System.out.println("Name : " + name);
        System.out.println("Age : " + age);
        System.out.println("Email : " + email);
        System.out.println("Phone Number : " + phno);

        s1.close();
    }
}
