public class que34 {
    private double x;
    private double y;
    private double z;

    public que34(double a) {
        this.x = a;
        this.y = a;
        this.z = a;
        printCoordinates();
    }

    public que34(double a, double b) {
        this.x = a;
        this.y = b;
        this.z = 0;
        printCoordinates();
    }

    public que34(double a, double b, double c) {
        this.x = a;
        this.y = b;
        this.z = c;
        printCoordinates();
    }

    private void printCoordinates() {
        System.out.println("Point3D coordinates: x = " + x + ", y = " + y + ", z = " + z);
    }

    public static void main(String[] args) {
        new que34(5.5);
        new que34(3.2, 4.8);
        new que34(1.1, 2.2, 3.3);
    }
}