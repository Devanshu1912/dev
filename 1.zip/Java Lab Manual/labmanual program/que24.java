public class que24 {

    final int CONSTANT_VALUE = 42;

    final void displayConstant() {
        System.out.println("The final constant value is: " + CONSTANT_VALUE);
    }
    
    public static void main(String[] args) {
        que24 demo = new que24();
        demo.displayConstant();
        FinalClass finalObj = new FinalClass();
        finalObj.showMessage();
    }
}

final class FinalClass {
    void showMessage() {
        System.out.println("This is a final class and cannot be extended.");
    }
}

