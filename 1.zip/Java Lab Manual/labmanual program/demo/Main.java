package demo;

import Animals.animal;

public class Main {
    public static void main(String[] args) {
    
        animal dog = new animal("Dog");
        animal cat = new animal("Cat");
        
        dog.makeSound();   
        cat.makeSound();  
        
        System.out.println("Animal name: " + dog.getName());
    }
}
