import java.util.Scanner;

public class p15 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the amount (P): ");
        double P = scanner.nextDouble();

        System.out.print("Enter the rate of interest (R): ");
        double R = scanner.nextDouble();

        System.out.print("Enter the time (N) : ");
        double N = scanner.nextDouble();

        double SI = (P * R * N) / 100;

        System.out.println("Simple Interest = " + SI);

        scanner.close();
    }
}

