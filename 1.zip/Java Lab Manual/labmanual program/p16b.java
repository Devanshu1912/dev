public class p16b {
    public static void main(String[] args) {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {

                
                if (i == 0) {
                    System.out.print("* ");
                }

                
                else if (i == 1) {
                    if (j == 0 || j == 1 || j == 3 || j == 4) {
                        System.out.print("* ");
                    } else {
                        System.out.print("  ");
                    }
                }

                
                else if (i == 2) {
                    if (j == 0 || j == 4) {
                        System.out.print("* ");
                    } else {
                        System.out.print("  ");
                    }
                }
            }
            System.out.println();
        }
    }
}

