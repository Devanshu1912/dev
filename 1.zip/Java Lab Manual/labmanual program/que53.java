import javax.swing.*;
import java.awt.event.*;

class que53 {
    public static void main(String[] args) {

        JFrame f = new JFrame("Addition of Two Numbers");

        JLabel l1 = new JLabel("Enter first number:");
        JLabel l2 = new JLabel("Enter second number:");
        JLabel result = new JLabel("Result:");
        JTextField t1 = new JTextField();
        JTextField t2 = new JTextField();
        JButton b = new JButton("Add");


        l1.setBounds(20, 30, 150, 25);
        t1.setBounds(170, 30, 100, 25);

        l2.setBounds(20, 70, 150, 25);
        t2.setBounds(170, 70, 100, 25);

        b.setBounds(20, 110, 80, 30);
        result.setBounds(170, 110, 100, 30);

        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int a = Integer.parseInt(t1.getText());
                int b = Integer.parseInt(t2.getText());
                int sum = a + b;
                result.setText("" + sum);
            }
        });

        f.add(l1); f.add(t1);
        f.add(l2); f.add(t2);
        f.add(b);  f.add(result);

        f.setSize(320, 200);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
