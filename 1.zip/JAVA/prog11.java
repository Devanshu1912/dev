public class prog11 {
    public static void main(String[] args) {
        int a = 10, b = 5;
        int result;
        boolean boolResult;

        System.out.println("=== Arithmetic Operators ===");
        System.out.println("a = " + a + ", b = " + b);
        System.out.println("a + b = " + (a + b)); 
        System.out.println("a - b = " + (a - b));  
        System.out.println("a * b = " + (a * b)); 
        System.out.println("a / b = " + (a / b));  
        System.out.println("a % b = " + (a % b)); 

        System.out.println("\n=== Unary Operators ===");
        System.out.println("a = " + a);
        System.out.println("++a = " + (++a));  
        System.out.println("a++ = " + (a++));  
        System.out.println("a after post-increment = " + a);
        System.out.println("--a = " + (--a));  
        System.out.println("a-- = " + (a--));  
        System.out.println("a after post-decrement = " + a);
        System.out.println("+a = " + (+a));    
        System.out.println("-a = " + (-a));    
        System.out.println("!true = " + (!true)); 

        System.out.println("\n=== Relational Operators ===");
        System.out.println("a == b: " + (a == b));  
        System.out.println("a != b: " + (a != b));  
        System.out.println("a > b: " + (a > b));    
        System.out.println("a < b: " + (a < b));    
        System.out.println("a >= b: " + (a >= b));  
        System.out.println("a <= b: " + (a <= b));  

        System.out.println("\n=== Logical Operators ===");
        boolean x = true, y = false;
        System.out.println("x && y: " + (x && y));  
        System.out.println("x || y: " + (x || y));  
        System.out.println("!x: " + (!x));         

        System.out.println("\n=== Bitwise Operators ===");
        System.out.println("a = " + a + ", b = " + b);
        System.out.println("a & b = " + (a & b));   
        System.out.println("a | b = " + (a | b));   
        System.out.println("a ^ b = " + (a ^ b));   
        System.out.println("~a = " + (~a));          
        System.out.println("a << 2 = " + (a << 2));
        System.out.println("a >> 2 = " + (a >> 2)); 
        System.out.println("a >>> 2 = " + (a >>> 2));
        System.out.println("\n=== Assignment Operators ===");
        int c = 10;
        System.out.println("c = " + c);
        c += 5;
        System.out.println("c += 5: " + c);
        c -= 3;
        System.out.println("c -= 3: " + c);
        c *= 2;
        System.out.println("c *= 2: " + c);
        c /= 4;
        System.out.println("c /= 4: " + c);
        c %= 3;
        System.out.println("c %= 3: " + c);
        c &= 2;
        System.out.println("c &= 2: " + c);
        c |= 1;
        System.out.println("c |= 1: " + c);
        c ^= 3;
        System.out.println("c ^= 3: " + c);
        c <<= 1;
        System.out.println("c <<= 1: " + c);
        c >>= 1;
        System.out.println("c >>= 1: " + c);
        c >>>= 1;
        System.out.println("c >>>= 1: " + c);

        System.out.println("\n=== Ternary Operator ===");
        int num1 = 15, num2 = 20;
        int max = (num1 > num2) ? num1 : num2;
        System.out.println("Max of " + num1 + " and " + num2 + " is " + max);
    }
}

