import java.util.Scanner;

public class sum {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] values = new int[10];
        int sumodd = 0; 
        int sumeven = 0;
        int sumall = 0;
        System.out.println("Enter 10 values:");
        
        for(int i = 0; i < 10; i++){
            values[i] = scanner.nextInt();
        }
        for(int value : values){
            sumall += value;
            if(value % 2 == 0){
                sumeven += value;
            } else {
                sumodd += value;
            }
        }
        System.out.println("Sum of even numbers: " + sumeven);
        System.out.println("Sum of odd numbers: " + sumodd);
        System.out.println("Sum of all numbers: " + sumall);
        scanner.close();
    }
}