class RunnableDemo implements Runnable{
    private Thread t;
    private String threadName;

    RunnableDemo(String name){
        threadName = name;
        System.out.println("Creating"+ threadName);
    }

    public void run(){
        System.out.println("Runn");
    }

}


public class t {
    
}
