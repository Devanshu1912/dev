import java.util.*;

public class p19 {
     public static void main(String[] args) {
        Random random = new Random();
        int[] numbers = new int[10]; 
        
        for (int i = 0; i < 10; i++) {
            numbers[i] = random.nextInt(100);
        }
        
        System.out.println("Generated 10 random numbers:");
        for (int i = 0; i < 10; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
     }
}

