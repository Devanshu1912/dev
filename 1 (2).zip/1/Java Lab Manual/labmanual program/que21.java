public class que21 {
    private String name;
    private int age;
    
    public que21(String name, int age) {
        this.name = name;  
        this.age = age; 
    }
    public void display() {
        System.out.println("Name: " + this.name + ", Age: " + this.age);
    }
    public static void main(String[] args) {
        que21 p = new que21("Devanshu", 25);
        p.display();  
    }
}

