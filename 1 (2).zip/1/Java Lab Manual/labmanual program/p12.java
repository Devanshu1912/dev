import java.util.*;
public class p12 {
        public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        System.out.print("Enter the base of triangle : ");
        double base = s.nextDouble();
        System.out.print("Enter the height of triangle : ");
        double height = s.nextDouble();
        double area = 0.5 * base * height;
        System.out.println("The area of the triangle is : " + area);

        s.close();

    }
    
    
}

