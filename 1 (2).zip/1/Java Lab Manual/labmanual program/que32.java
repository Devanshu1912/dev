public class que32 {

    public void test() {
        System.out.println("Test method with no parameters called.");
    }

    public void test(int a) {
        System.out.println("Test method with one integer parameter: " + a);
    }

    public void test(int a, int b) {
        System.out.println("Test method with two integer parameters: " + a + " and " + b);
    }

    public void test(double d) {
        System.out.println("Test method with one double parameter: " + d);
    }

    public static void main(String[] args) {
        que32 demo = new que32();
        demo.test();           
        demo.test(5);         
        demo.test(5, 10);      
        demo.test(3.14);      
    }
}

