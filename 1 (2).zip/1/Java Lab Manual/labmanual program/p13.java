import java.util.Scanner;

public class p13 {
    public static void main(String[] args) {
        Scanner s1 = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = s1.nextDouble();

        double area = 3.14 * radius * radius;
        
        System.out.println("The area of the circle is: " + area);
        s1.close();
    }

}
