public class p18 {
    
    public static void main(String[] args) {
        
        int width1 = 110;
        int height1 = 20;
        int depth1 = 15;
        int volume1 = width1 * height1 * depth1;
        System.out.println("Volume of first box: " + volume1);
      
        int width2 = 23;
        int height2 = 6;
        int depth2 = 9;
        int volume2 = width2 * height2 * depth2;
        System.out.println("Volume of second box: " + volume2); 
    }
}
