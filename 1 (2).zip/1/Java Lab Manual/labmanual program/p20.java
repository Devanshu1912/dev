public class p20 {
    public static void main(String[] args) {
        
        if (args.length == 0) {
            System.out.println("hello");
            return;
        }
        
        String original = args[0].toLowerCase(); 
        String reversed = new StringBuilder(original).reverse().toString();
        
        
        if (original.equals(reversed)) {
            System.out.println("\"" + args[0] + "\" is a palindrome.");
        } else {
            System.out.println("\"" + args[0] + "\" is not a palindrome.");
        }
    }
}
