import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class que56 extends JFrame implements ActionListener {
    JComboBox<String> comboBox;
    JLabel label;

    que56() {
        setTitle("Combo Box Example");
        setSize(400, 150);
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel selectLabel = new JLabel("Select a Place: ");
        add(selectLabel);

        String[] states = {"Gujarat", "Maharashtra", "Rajasthan", "Punjab", "Karnataka"};
        comboBox = new JComboBox<>(states);
        comboBox.addActionListener(this);
        add(comboBox);

        label = new JLabel("Selected Place: " + comboBox.getSelectedItem());
        add(label);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        label.setText("Selected Place: " + comboBox.getSelectedItem());
    }

    public static void main(String[] args) {
        new que56();
    }
}