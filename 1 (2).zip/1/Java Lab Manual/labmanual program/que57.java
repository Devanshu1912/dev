import javax.swing.*;
import java.awt.event.*;

public class que57 extends JFrame implements ActionListener {

    JTextField txtName, txtMobile;
    JRadioButton rbMale, rbFemale;
    JComboBox<String> cbDay, cbMonth, cbYear;
    JTextArea taAddress, taOutput;
    JButton btnSubmit;

    public que57() {

        setTitle("Registration Form");
        setSize(500, 350);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel l1 = new JLabel("Name");
        l1.setBounds(30, 40, 80, 20);
        add(l1);

        txtName = new JTextField();
        txtName.setBounds(120, 40, 150, 20);
        add(txtName);

        JLabel l2 = new JLabel("Mobile");
        l2.setBounds(30, 70, 80, 20);
        add(l2);

        txtMobile = new JTextField();
        txtMobile.setBounds(120, 70, 150, 20);
        add(txtMobile);

        JLabel l3 = new JLabel("Gender");
        l3.setBounds(30, 100, 80, 20);
        add(l3);

        rbMale = new JRadioButton("Male");
        rbFemale = new JRadioButton("Female");
        rbMale.setBounds(120, 100, 70, 20);
        rbFemale.setBounds(190, 100, 80, 20);

        ButtonGroup bg = new ButtonGroup();
        bg.add(rbMale);
        bg.add(rbFemale);

        add(rbMale);
        add(rbFemale);

        JLabel l4 = new JLabel("DOB");
        l4.setBounds(30, 130, 80, 20);
        add(l4);

        String[] days = {
            "1","2","3","4","5","6","7","8","9","10",
            "11","12","13","14","15","16","17","18",
            "19","20","21","22","23","24","25","26",
            "27","28","29","30","31"
        };
        String[] months = {"Jan","Feb","Mar","Apr","May","Jun",
                           "Jul","Aug","Sep","Oct","Nov","Dec"};
        String[] years = {"1998","1999","2000","2001","2002"};

        cbDay = new JComboBox<>(days);
        cbMonth = new JComboBox<>(months);
        cbYear = new JComboBox<>(years);

        cbDay.setBounds(120, 130, 50, 20);
        cbMonth.setBounds(175, 130, 60, 20);
        cbYear.setBounds(240, 130, 60, 20);

        add(cbDay);
        add(cbMonth);
        add(cbYear);

        JLabel l5 = new JLabel("Address");
        l5.setBounds(30, 160, 80, 20);
        add(l5);

        taAddress = new JTextArea();
        taAddress.setBounds(120, 160, 180, 60);
        add(taAddress);

        btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(120, 230, 100, 25);
        btnSubmit.addActionListener(this);
        add(btnSubmit);

        taOutput = new JTextArea();
        taOutput.setEditable(false);
        taOutput.setBounds(320, 40, 150, 180);
        add(taOutput);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String name = txtName.getText();
        String mobile = txtMobile.getText();
        String gender = rbMale.isSelected() ? "Male"
                       : rbFemale.isSelected() ? "Female" : "";
        String dob = cbDay.getSelectedItem() + "/" +
                     cbMonth.getSelectedItem() + "/" +
                     cbYear.getSelectedItem();
        String addr = taAddress.getText();

        String text = "Name : " + name + "\n"
                    + "Mobile : " + mobile + "\n"
                    + "Gender : " + gender + "\n"
                    + "DOB : " + dob + "\n"
                    + "Address : " + addr;

        taOutput.setText(text);
    }

    public static void main(String[] args) {
        new que57().setVisible(true);
    }
}
