print("Devanshu Jogani")


numbers = (12,3,4,5,6,7,8,9)

# Declaring the tuple

count_odd = 0
count_even = 0

for x in numbers:
    if x%2:
        count_odd += 1
    else:
        count_even += 1
        
print("Number of even numbers:", count_even)
print("Number of odd numbers:", count_odd)
        


# loop iterates through the list


datalist = [1452,11.23,1+2j,True,'Istarlibrary',(0,-1),[5,12],{"class":"V","section":"A"}]

for item in datalist:
    print("Type of ",item,"is",type(item))



# loop iterates through the Dictionary
        # 1) loop iterates through its keys

color = {"c1":"Red","c2":"Green","c3":"Orange"}
for key in color.keys():
    print(key)


        # 2) loop iterates through its keys
        
color = {"c1":"Red","c2":"Green","c3":"Orange"}
for value in color.values():
    print(value)






