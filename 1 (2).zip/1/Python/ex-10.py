print("Devanshu Jogani")

str1 = "String"
print(str1)
str2 = 'string'
print(str2)
str3 = "string'
print(str3)
str4 = 'string"
print(str4)
str5 = "Day's"
print(str5)
str6 = 'Day"s'
print(str6)

