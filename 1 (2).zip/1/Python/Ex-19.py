
print("Devanshu Jogani")


# + Operator to create new tuple  &   * Operator to repeate a tuple


tup1 = (1,2,3)
tup2 = (4,5,6)
tup3 = (7,8,9)

tup_123 = tup1 + tup2 + tup3

print(tup_123)

print(tup1*4)
