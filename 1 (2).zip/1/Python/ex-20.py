print("Devanshu Jogani")

# Lists

my_list1 = [5, 12, 13, 14]
print(my_list1)


my_list2 = ['Red', 'blue', 'black', 'white']
print(my_list2)


my_list3 = ['red', 12, 112.12]
print(my_list3)


my_list=[]
print(my_list)


color_list=["RED", "BLUE", "GREEN", "BLACK"]
color_list[0]

print(color_list[0],color_list[3])

color_list[-1]


# slice list


print(color_list[0:2])
print(color_list[1:2])
print(color_list[1:-2])
print(color_list[:3])
print(color_list[:])


# List Mutable

print(color_list[0])

color_list[0] = "WHITE"
print(color_list)

print(color_list[0])


# Using + & * operator


color_list1 = ["White", "Yellow"]
color_list2 = ["Red", "Blue"]
color_list3 = ["Green", "Black"]

color_list = color_list1 + color_list2 + color_list3
print(color_list)

number = [1,2,3]
print(number[0]*4)

print(number*4)
