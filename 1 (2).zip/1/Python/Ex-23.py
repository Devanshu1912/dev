
print("Devanshu Jogani")


#  String capitalize() Method

str1 = "this is string example!!!"
print("str1.capitalize():",str1.capitalize())  # In sentence first letter capital


#  String title() Method

str1 = "this is string example!!!"
print(str1.title())         # All words first letter capital


#   String isalnum() Method

str1 = "thisis2025"  # No space in this string
print(str1.isalnum())
str1 = "this is string example!!!"
print(str1.isalnum())


#   String isalpha() Method

str1 = "this"   # No space & digit in this string
print(str1.isalpha())
str1 = "this is 2025"
print(str1.isalpha())


#   String isdigit() Method

str1 = "123456"  # Only digit in this string
print(str1.isdigit())
str1 = "this is string example!!!"
print(str1.isdigit())


