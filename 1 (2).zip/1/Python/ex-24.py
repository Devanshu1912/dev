print("Devanshu Jogani")


#   String islower() Method

str1 = "THIS is string example!!!"
print(str1.islower())
str1 = "this is string example!!!"
print(str1.islower())


#   String isupper() Method

str1 = "THIS IS STRING EXAMPLE"
print(str1.isupper())
str1 = "THIS is string example"
print(str1.isupper())


#   String join() Method

s = "-"
seq = ("a","b","c")     # This is sequence of strings.
print(s.join(seq))


#   String len() Method

str1 = "this is string example!!!"
print("Length of the string : ",len(str1))


#   String lower() Method

str1 = "THIS IS STRING EXAMPLE"
print(str1.lower())
str1 = "THIS IS STRING EXAMPLE"
print(str1.lower())

#   String upper() Method

str1 = "this is string example!!!"
print(str1.upper())


#   String  swapcase() Method

str1 = "this is string example!!!"
print(str1.swapcase())
str1 = "This Is String Example!!!"
print(str1.swapcase())


#   String  strip() Method

str1 = "*****this is string example!!!*****"
print(str1.strip('*'))          


#   String lstrip() Method

str1 = "     this is string example!!!     "
print(str1.lstrip()) 
str1 = "*****this is string example!!!*****"
print(str1.lstrip('*'))



#   String rstrip() Method

str1 = "     this is string example!!!     "
print(str1.rstrip()) 
str1 = "*****this is string example!!!*****"
print(str1.rstrip('*'))


#   String replace() Method

str1 = "this is string example...!!!this is ready string"
print(str1.replace("is","was"))
print(str1.replace("is","was",3))
