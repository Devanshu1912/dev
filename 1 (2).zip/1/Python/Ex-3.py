
print("Devanshu Jogani")
x=10
if x>0:
        print("x is positive");

#single space
#single tab

