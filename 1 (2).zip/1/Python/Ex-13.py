print("Devanshu Jogani")



#strings are immutable




string1 = "PYTHON TUTORIAL"
string1[0]
string1[0] = 'A'
string1[0]
