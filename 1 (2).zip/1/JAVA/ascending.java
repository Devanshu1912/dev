import java.util.Scanner;
import java.util.Arrays;

public class ascending {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] arr = new int[5];
        System.out.println("Enter 5 values:");

        for(int i=0;i<5;i++){
            arr[i] = scanner.nextInt();
        }
        Arrays.sort(arr);

        System.out.println("values in ascending order:");
        for(int value:arr){
            System.out.println(value + " ");
            scanner.close();
        }
    }
}
