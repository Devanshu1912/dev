public class prog16d {
    public static void main(String[] args) {
        int start = 1;
        int end = 6;

        for (int i = start; i <= end; i++) {
            for (int space = start; space < i; space++) {
                System.out.print(" ");
            }

            for (int num = i; num <= end; num++) {
                System.out.print(num + " ");
            }

            System.out.println();
        }
    }
}

