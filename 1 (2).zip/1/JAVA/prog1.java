public class prog1 {
    public static void main(String[] args) {
        if (System.out.printf("Devanshu Jogani\n") == null) {
        }
    } 
}
